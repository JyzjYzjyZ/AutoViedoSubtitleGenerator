from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5 import QtWidgets
from PyQt5.QtCore import pyqtSignal
import warnings,gui,cv2

try:
    from Gui_body import ui_button_with_shadow
except:
    from .Gui_body import ui_button_with_shadow

'''
显而易见 这是未完成版本
但是大差不差
'''


def changeToOpacity(Form: QPushButton, Alpha=0):
    opacity = QtWidgets.QGraphicsOpacityEffect()
    opacity.setOpacity(Alpha)
    Form.setGraphicsEffect(opacity)

class changQimgeThred(QThread):
    # changeFrame = pyqtSignal(QImage)

    def __init__(self,vc,label:QLabel):
        super(changQimgeThred, self).__init__()
        self._vc = vc
        self._label = label

    def setFrame(self,frameInt):
        if frameInt == -1:
            return
        self.frameInt = frameInt

    def Change(self):
        '''
            此处，当label更新，也调用此。slot传入-1
            -1不会被记录，但依然调用start函数
            故，会导致上一次输入的frameInt在新的size下刷新
            动态更新，get@!
        '''
        self._vc.set(cv2.CAP_PROP_POS_FRAMES, self.frameInt )
        rval, frame = self._vc.read()
        if rval:
            rgbImage = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgbImage.shape
            bytesPerLine = ch * w
            convertToQtFormat = QImage(rgbImage.data, w, h, bytesPerLine, QImage.Format_RGB888)
            convertToQtFormat = convertToQtFormat.scaled(self._label.width(), self._label.height(),
                                                         aspectRatioMode=Qt.KeepAspectRatioByExpanding,transformMode=Qt.SmoothTransformation)
            p = QPixmap.fromImage(convertToQtFormat)
            self._label.setPixmap(p)

    def run(self) -> None:
        self.Change()



class ButtonWithSpaceKey(QPushButton):
    '''
    为preview的小窗口的空格键反馈
    '''
    def __init__(self,Form,filename):
        super(ButtonWithSpaceKey, self).__init__(Form)
        self.filemane = filename
        # alpha
        changeToOpacity(self)

class QLableWithResizeSign(QLabel):
    resizeSignal = pyqtSignal(int)

    def __init__(self,Form):
        super(QLableWithResizeSign, self).__init__(Form)

    # def sendProgress(self,From:QProgressBar):
    #     self.progress = From

    def resizeEvent(self, a0) -> None:
        # if self.progress:
        self.resizeSignal.emit(-1)
        super(QLableWithResizeSign, self).resizeEvent(a0)


class VideoPreviewQt():
    '''小窗口的preview'''
    def _getMax(self):
        self.vc = cv2.VideoCapture(self.filename)
        self.maxFrame =  int(self.vc.get(cv2.CAP_PROP_FRAME_COUNT))
        self.StyleSheet = '''
        QScrollArea QScrollBar:vertical[
            height: {height}px;
            width: {width}px;
            background:transparent;
            padding-right:{margin}px;
            padding-top:{padding}px;
            padding-bottom:{padding}px;
            ]
        QScrollArea QScrollBar::handle:vertical[
            background:#C4C4C4;
            border-radius:{radius}px;
            ]
        QScrollArea QScrollBar::handle:vertical:hover[
            background:#F09428;
            border-radius:{radius}px;
            ]
        QScrollArea QScrollBar::add-page:vertical,QScrollBar::sub-page:vertical[
        background:transparent;border-radius:{radius}px;
        ]
        QScrollArea QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical[
        height:0px;width:0px;
        ]

        QScrollArea QScrollBar:horizontal[
            height: {height}px;
            width: {width};
            border-radius:{radius}px;
            background:transparent;
            padding-bottom:{margin}px;
            padding-left:{padding}px;
            padding-right:{padding}px;
            ]
        QScrollArea QScrollBar::handle:horizontal[
            background:#C4C4C4;
            border-radius:{radius}px;
            ]
        QScrollArea QScrollBar::handle:horizontal:hover[
            background:#F09428;
            border-radius:{radius}px;
            ]
        QScrollArea QScrollBar::add-page:horizontal,QScrollBar::sub-page:horizontal[
        background:transparent;border-radius:{radius}px;
        ]
        QScrollArea QScrollBar::add-line:horizontal,QScrollBar::sub-line:horizontal[
        height:0px;width:0px;
        ]
'''.format(radius = 3,padding=1,margin=1,width=10,height=8).replace('[','{').replace(']','}')# round(self.maxFrame/10)

    def __init__(self,label:QLabel,filename):
        # label.setStyleSheet()
        self.filename = filename
        self._label = label
        self._getMax()
        self.container = QLableWithResizeSign(label)
        self.imageThreaad = changQimgeThred(vc =self.vc,label=self.container)
        label.setStyleSheet(self.StyleSheet)
        self.horizontalScrollBar = QScrollBar(label)
        self.horizontalScrollBar.setOrientation(Qt.Horizontal)
        self.horizontalScrollBar.setMaximum(self.maxFrame)# int(self.maxFrame/3)
        self.defaultValue = round(self.maxFrame/3)
        self.defaultPageStep=round(self.maxFrame/10)
        self.horizontalScrollBar.setValue(self.defaultValue)
        self.horizontalScrollBar.setPageStep(self.defaultPageStep)
        main_vlayout = QVBoxLayout()
        # self.container.setFrameShape(QFrame.StyledPanel)
        self.hitbox = ButtonWithSpaceKey(self.container,filename)
        self.container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        # self.container.setText('111111111')
        mini_glayout = QGridLayout(self.container)

        self.hitbox.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
        #set
        self.hitbox.setContentsMargins(0,0,0,0)
        self.container.setContentsMargins(0,0,0,0)
        self.horizontalScrollBar.setContentsMargins(0,0,0,0)
        main_vlayout.setContentsMargins(0,0,0,0)
        main_vlayout.setSpacing(0)
        mini_glayout.setContentsMargins(0,0,0,0)
        mini_glayout.setSpacing(0)
        self.container.setLayout(mini_glayout)
        mini_glayout.addWidget(self.hitbox)
        main_vlayout.addWidget(self.container)
        main_vlayout.addWidget(self.horizontalScrollBar)
        label.setLayout(main_vlayout)
        self._initFrameCreate()

    def startAchange(self,frameInt):
        # 当更新时，输出-1
        self.imageThreaad.setFrame(frameInt)
        self.imageThreaad.start()

    def _initFrameCreate(self):
        self.startAchange(self.defaultValue)


def sumDic(dic1:dict,dic2:dict):
    return dict(dic1,**dic2)



class Element_data():

    def __init__(self,path,Form:QWidget = None):
        mainGroupBox = QGroupBox(Form)
        mainGroupBox.setObjectName('mainGroupBox')
        self.mainGroupBox = mainGroupBox

        try:
            # super(QWidget, self).__init__(Form)
            self.WidgetObj = QWidget(mainGroupBox) # 这玩意就是主要的元素
        except:
            # super(QWidget, self).__init__()
            self.WidgetObj = QWidget()
        self.WidgetObj.setObjectName('WidgetObj')

        self.path = path
        self.mainGroupBox.setStyleSheet(
            r'''

            .is_scrollArea{
            border:0px;
            }
            
            .scrollWidget_element{
                background:#EDEDED
            }
            
            #mainGroupBox{
                background:#EDEDED;
            }
            
            #WidgetObj{
                background:#EDEDED;
            }
            
            QScrollArea QScrollBar:vertical{
                width: 10px;
                background:transparent;
                padding-right:2px;
                padding-top:5px;
                padding-bottom:5px;
                border-radius:0px;
                }
            QScrollArea QScrollBar::handle:vertical{
                background:#C4C4C4;
                border-radius:4px;
                }
            QScrollArea QScrollBar::handle:vertical:hover{
                background:#F09428;
                border-radius:4px;
                }
            QScrollArea QScrollBar::add-page:vertical,QScrollBar::sub-page:vertical{
            background:transparent;border-radius:4px;
            }
            QScrollArea QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{
            height:0px;width:0px;
            }

            QScrollArea QScrollBar:horizontal{
                height: 10px;
                border-radius:4px;
                background:transparent;
                padding-bottom:2px;
                padding-left:5px;
                padding-right:5px;
                border-radius:0px;
                }
            QScrollArea QScrollBar::handle:horizontal{
                background:#C4C4C4;
                border-radius:4px;
                }
            QScrollArea QScrollBar::handle:horizontal:hover{
                background:#F09428;
                border-radius:4px;
                }
            QScrollArea QScrollBar::add-page:horizontal,QScrollBar::sub-page:horizontal{
            background:transparent;border-radius:4px;
            }
            QScrollArea QScrollBar::add-line:horizontal,QScrollBar::sub-line:horizontal{
            height:0px;width:0px;
            }
            
            '''
        )

        main_vlayout = QVBoxLayout(mainGroupBox)
        main_vlayout.setSpacing(0)
        main_vlayout.setContentsMargins(0,0,0,0)
        self.Create_element()
        ProgressBar =  self._createProgressBar(mainGroupBox)
        main_vlayout.addWidget(ProgressBar)
        main_vlayout.addWidget(self.WidgetObj)
        self._clickSelect()


    def Create_element(self):
        '''Main'''
        self.MainLayout = QHBoxLayout(self.WidgetObj)
        self.MainLayout.setContentsMargins(15, 5, 10, 5)
        self.MainLayout.setSpacing(0)
        data_Layout = QHBoxLayout()

        '''Path'''
        scrollArea_dataPath = QScrollArea()
        scrollArea_dataPath.setProperty('class', 'is_scrollArea')
        scrollArea_dataPath.setWidgetResizable(True)
        scrollArea_dataPath.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        scrollArea_dataPath.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        scroll_dataPath_Widget = QWidget()
        scroll_dataPath_Widget.setProperty('class','scrollWidget_element')
        scroll_dataPath_Widget.setContentsMargins(0,0,0,0)
        scroll_dataPath_Widget_layout = QVBoxLayout(scroll_dataPath_Widget)
        dataPath_label = QLabel()
        dataPath_label.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        dataPath_label.setText(
            f'Path: {self.path}    -*-快速找到文本所在行数-*-')
        #hitbox
        dataPath_glayout = QGridLayout(dataPath_label)
        dataPath_hitbox = QPushButton(dataPath_label)
        changeToOpacity(dataPath_hitbox)
        dataPath_glayout.setSpacing(0)
        dataPath_glayout.setContentsMargins(0,0,0,0)
        dataPath_glayout.addWidget(dataPath_hitbox)
        self.dataPath_hitbox = dataPath_hitbox
        dataPath_hitbox.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # set max by label
        scrollArea_dataPath.setMaximumWidth(dataPath_label.width())
        # set
        scroll_dataPath_Widget_layout.addWidget(dataPath_label)
        scrollArea_dataPath.setWidget(scroll_dataPath_Widget)
        '''Imf'''
        scrollArea_dataImf = QScrollArea()
        scrollArea_dataImf.setProperty('class', 'is_scrollArea')
        scrollArea_dataImf.setWidgetResizable(True)
        scrollArea_dataImf.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        scrollArea_dataImf.setSizePolicy(QSizePolicy.MinimumExpanding,QSizePolicy.Expanding)
        scroll_dataImf_Widget = QWidget()
        scroll_dataImf_Widget.setProperty('class','scrollWidget_element')
        scroll_dataImf_Widget_layout = QVBoxLayout(scroll_dataImf_Widget)
        dataImf_label = QLabel()
        dataImf_label.setText(
            r'I222mf\nImf\nI')
        self.dataImf_label = dataImf_label
        dataImf_label.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        #hitbox
        dataImf_glayout = QGridLayout(dataImf_label)
        dataImf_hitbox = QPushButton(dataImf_label)
        changeToOpacity(dataImf_hitbox)
        dataImf_glayout.setSpacing(0)
        dataImf_glayout.setContentsMargins(0, 0, 0, 0)
        dataImf_glayout.addWidget(dataImf_hitbox)
        self.dataImf_hitbox = dataImf_hitbox
        dataImf_hitbox.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        # set
        scroll_dataImf_Widget_layout.addWidget(dataImf_label)
        scrollArea_dataImf.setWidget(scroll_dataImf_Widget)



        '''preview'''
        preview = QLabel()
        preview_ClsInstance =  VideoPreviewQt(preview,self.path)
        # preview_ClsInstance.hitbox.Is_Space_pysignal.connect(print)
        preview.setText('preview-*-快速找到文本所在行数-*-')
        preview_ClsInstance.horizontalScrollBar.valueChanged.connect(preview_ClsInstance.startAchange)
        # preview_ClsInstance.startAchange(100)
        self.preview_ClsInstance = preview_ClsInstance
        self.preview = preview

        # self.preview_ClsInstance.container.sendProgress(preview_ClsInstance.horizontalScrollBar)# 传入ProgressBar以获取vvalue数据
        self.preview_ClsInstance.container.resizeSignal.connect(preview_ClsInstance.startAchange)# 在label sizeChange 后重新载入

        '''ui'''
        ShadowAdditionalParameter = {
            'color':[30,30,30],
            'alpha':100,
            'radius':4,
            'offset':[0,2],
        }
        SizeAdditionalParameter = {
            'Margins_ui':0,
            'Margins_button_hitbox':0,
            'pixSize':[40,40],
            # 如果图标宽度过宽 考虑是否是图标的问题
        }

        ui_VboxLayout = QVBoxLayout()
        ui_open_class = ui_button_with_shadow(f'{gui.path_head}/ui_svg/open_in_explorer.svg',self.WidgetObj,
                                              **sumDic(ShadowAdditionalParameter,SizeAdditionalParameter))
        ui_play_class = ui_button_with_shadow(f'{gui.path_head}/ui_svg/preview.svg',self.WidgetObj,
                                              **sumDic(ShadowAdditionalParameter,SizeAdditionalParameter))
        ui_open = ui_open_class.FrameObj
        self.b_open = ui_open_class.button
        ui_play = ui_play_class.FrameObj
        self.b_play = ui_play_class.button


        ui_VboxLayout.addWidget(ui_play)
        ui_VboxLayout.addWidget(ui_open)
        '''set'''''
        data_Layout.addWidget(scrollArea_dataImf,1)
        data_Layout.addWidget(scrollArea_dataPath,9999)
        data_Layout.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.MainLayout.addWidget(preview)
        self.MainLayout.addLayout(ui_VboxLayout)
        self.MainLayout.addLayout(data_Layout)

        self.WidgetObj.setSizePolicy(QSizePolicy.Preferred ,QSizePolicy.Fixed)



    def _clickSelect(self):
        self.IsSelect = False
        def changeBackgroundColor():
            FalseColor = '''
            .scrollWidget_element{
                background:#EDEDED
            }
            #mainGroupBox{
                background:#EDEDED;
            }
            
            #WidgetObj{
                background:#EDEDED;
            }'''
            TrueColor = '''
            .scrollWidget_element[
                background:#{0}
            ]
            #WidgetObj[
                background:#{0};
            ]
            #mainGroupBox[
                background:#{0};
            ]
            
            '''.format('FFCC33').replace('[','{').replace(']','}')
            addStyle = '''
            .is_scrollArea{
            border:0px;
            }
            QScrollArea QScrollBar:vertical{
                width: 10px;
                background:transparent;
                padding-right:2px;
                padding-top:5px;
                padding-bottom:5px;
                border-radius:0px;
                }
            QScrollArea QScrollBar::handle:vertical{
                background:#C4C4C4;
                border-radius:4px;
                }
            QScrollArea QScrollBar::handle:vertical:hover{
                background:#F09428;
                border-radius:4px;
                }
            QScrollArea QScrollBar::add-page:vertical,QScrollBar::sub-page:vertical{
            background:transparent;border-radius:4px;
            }
            QScrollArea QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{
            height:0px;width:0px;
            }

            QScrollArea QScrollBar:horizontal{
                height: 10px;
                border-radius:4px;
                background:transparent;
                padding-bottom:2px;
                padding-left:5px;
                padding-right:5px;
                border-radius:0px;
                }
            QScrollArea QScrollBar::handle:horizontal{
                background:#C4C4C4;
                border-radius:4px;
                }
            QScrollArea QScrollBar::handle:horizontal:hover{
                background:#F09428;
                border-radius:4px;
                }
            QScrollArea QScrollBar::add-page:horizontal,QScrollBar::sub-page:horizontal{
            background:transparent;border-radius:4px;
            }
            QScrollArea QScrollBar::add-line:horizontal,QScrollBar::sub-line:horizontal{
            height:0px;width:0px;
            }
            '''
            if self.IsSelect:
                self.mainGroupBox.setStyleSheet(f"{TrueColor}\n{addStyle}")
            else:
                self.mainGroupBox.setStyleSheet(f"{FalseColor}\n{addStyle}")
        def inversion():
            self.IsSelect = False if self.IsSelect else True
            changeBackgroundColor()

        self.dataPath_hitbox.clicked.connect(inversion)
        self.dataImf_hitbox.clicked.connect(inversion)


    def _createProgressBar(self,Form):
        container = QFrame(Form)
        grid_layout = QGridLayout(container)

        grid_layout.setSpacing(0)
        grid_layout.setContentsMargins(3,2,3,1)
        self.progressBar = QProgressBar(container)
        self.progressBar.setStyleSheet(
            '''
                QProgressBar [
                    background-color: #{background};
                    border: 0px;
                ]
                QProgressBar::chunk [
                    background-color: #{chunk};
                ]
            '''.format(background="D8D8D8",chunk='EBA14B').replace('[','{').replace(']','}')
            # green:52D35F  orange:F09428
        )
        self.progressBar.setMaximum(10000)
        self.progressBar.setTextVisible(False)
        self.progressBar.setMaximumHeight(6)
        self.progressBar.setMinimumHeight(6)
        grid_layout.addWidget(self.progressBar)
        return container


    def changeProgress(self,floatProgress):
        self.progressBar.setValue(round(floatProgress*100))



